<?php
/*
front controller (chef d'orchestre) de l'application
placer ici tous les fichiers de config (constantes, parametrage, etc.)

*/

require_once('config/classload.php');

echo "<H1>site en construction</H1>";



?>
