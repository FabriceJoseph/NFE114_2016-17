<?php

class Genre{

	private libelle;
	
	public function __construct()
	
	/* getter */
	
	public function getLibelle(){
		return $this->libelle;
	}

}


?>
