<?php

class Promotion{
		
		private tauxReduc;
		
		public function __construct()
		
		/** getter **/
		public function getTxReduc(){
			return $this->tauxReduc;
		}

}

?>
