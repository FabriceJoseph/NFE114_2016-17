<?php

class Gestionnaire{

	private $mail;
	
	
	public function __construct()
	
	
	/*getter*/
	
	public function getMail(){
		return $this->mail;
	}

}


?>
