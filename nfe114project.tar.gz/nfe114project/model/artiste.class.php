<?php

class Artiste{

	/*identite est un objet individu*/
	private $identite;
	private $specialite;
	
	public function __construct()
	
	
	/* getter */
	
	public function getIdentite(){
		return $this->identite;
	}
	
	public function getSpecialite(){
		return $this->specialite;
	}

}


?>
