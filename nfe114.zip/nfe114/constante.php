<?php

$server=$_SERVER['SERVER_NAME'];
define('SERVER_NAME',$server,true);



?>
