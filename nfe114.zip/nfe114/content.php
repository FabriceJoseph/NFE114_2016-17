<?php

    require_once 'functions.php';
	
    $nowPlaying = get_default_spectacle();
    $playingSoon = get_default_futur_spectacle();

   //print_r($nowPlaying);

   //nowPlaying($nowPlaying);

   //print_r($playingSoon);


?>
